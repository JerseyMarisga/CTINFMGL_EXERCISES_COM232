import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class LoginPageController_Number {

    @FXML
    private Button btn_0;

    @FXML
    private Button btn_1;

    @FXML
    private Button btn_2;

    @FXML
    private Button btn_3;

    @FXML
    private Button btn_4;

    @FXML
    private Button btn_5;

    @FXML
    private Button btn_6;

    @FXML
    private Button btn_7;

    @FXML
    private Button btn_8;

    @FXML
    private Button btn_9;

    @FXML
    private Button btn_next;

    @FXML
    private Label btn_signUp;

    @FXML
    private Hyperlink hl_helpCenter;

    @FXML
    private Label lbl_titleGcash;

    @FXML
    private TextField tf_number;

    @FXML
    void onBtn0Clicked(ActionEvent event) {

    }

    @FXML
    void onBtn1Clicked(ActionEvent event) {

    }

    @FXML
    void onBtn2Clicked(ActionEvent event) {

    }

    @FXML
    void onBtn3Clicked(ActionEvent event) {

    }

    @FXML
    void onBtn4Clicked(ActionEvent event) {

    }

    @FXML
    void onBtn5Clicked(ActionEvent event) {

    }

    @FXML
    void onBtn6Clicked(ActionEvent event) {

    }

    @FXML
    void onBtn7Clicked(ActionEvent event) {

    }

    @FXML
    void onBtn8Clicked(ActionEvent event) {

    }

    @FXML
    void onBtn9Clicked(ActionEvent event) {

    }

    @FXML
    void onBtnNextClicked(ActionEvent event) {

    }

    @FXML
    void onBtnSignUpClicked(MouseEvent event) {

    }

    @FXML
    void onHyperLinkBtnClicked(ActionEvent event) {

    }
}